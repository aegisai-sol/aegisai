@echo off
REM AegisAI desktop miner
REM Simulation:  start.bat
REM PoV-R live:  python -m aegis_miner --pov-wallet <pubkey>
REM   fetch→solve→unsigned claim msg (no keys). Sign in Phantom, then claim.
REM Offline demo: python -m aegis_miner --pov-local --pov-n 8
cd /d %~dp0
python main.py %*
pause
