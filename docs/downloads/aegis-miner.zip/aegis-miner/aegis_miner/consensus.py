"""Multi-node fetch consensus (PoV-R).
Independent nodes each re-fetch the cited URL and run the Proof-of-Source check.
A receipt is VALID when >= quorum nodes agree on the content hash AND/OR the verdict.
Nodes are callables (url, claim_text) -> result dict; remote miners plug in the same way."""
import hashlib, json
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from . import verify

def local_node(node_id, page_fetcher=verify.fetch_page):
    def run(url, claim_text):
        r = verify.check_url_only(url, page_fetcher=page_fetcher, claim_text=claim_text)
        return dict(r, node=node_id)
    run.node_id = node_id
    return run

def http_node(node_id, endpoint, timeout=15):
    """Remote miner: POST {url, claim} to endpoint/v1/fetch-check."""
    import urllib.request
    def run(url, claim_text):
        req = urllib.request.Request(endpoint.rstrip("/") + "/v1/fetch-check",
            data=json.dumps({"url": url, "claim": claim_text}).encode(), headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as r: return dict(json.loads(r.read()), node=node_id)
    run.node_id = node_id
    return run

def consensus(url, claim_text, nodes, quorum=2, weights=None, min_strength=0.0):
    """weights: optional {node_id: float>0}. When given, the verdict is picked by WEIGHTED tally
    (sum of voter weights) instead of raw count; quorum still requires >= quorum distinct agreeing nodes.
    Missing node ids default to weight 1.0. Hash agreement stays count-based (bytes are bytes)."""
    if len(nodes) < quorum: raise ValueError(f"need >= {quorum} nodes")
    def safe(n):
        try: return n(url, claim_text)
        except Exception as e: return {"node": getattr(n, "node_id", "?"), "vote": "UNSURE", "error": (str(e) or type(e).__name__)[:100]}
    with ThreadPoolExecutor(max_workers=len(nodes)) as ex: results = list(ex.map(safe, nodes))
    hashes = Counter(r["source_hash"] for r in results if r.get("source_hash"))
    votes = Counter(r.get("vote") for r in results if r.get("vote") and not r.get("error"))
    top_hash, hash_n = hashes.most_common(1)[0] if hashes else (None, 0)
    top_vote, vote_n = votes.most_common(1)[0] if votes else (None, 0)
    vote_weight = total_weight = None
    if weights is not None:
        import math
        for k, v in weights.items():  # reject poisoned weights (negative/NaN/inf/bool) before tallying
            if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0:
                raise ValueError(f"invalid weight for {k!r}")
        wt = Counter()
        for r in results:
            if r.get("vote") and not r.get("error"): wt[r["vote"]] += float(weights.get(r.get("node"), 1.0))
        total_weight = round(sum(wt.values()), 6)
        if wt:  # deterministic tie-break: higher weight, then higher count, then vote name
            top_vote = max(wt, key=lambda v: (wt[v], votes[v], str(v))); vote_n = votes[top_vote]
            vote_weight = round(wt[top_vote], 6)
    hash_ok, vote_ok = hash_n >= quorum, vote_n >= quorum and top_vote != "UNSURE"
    if hash_ok and vote_ok: status = "VALID"            # same bytes, same verdict
    elif vote_ok: status = "VALID_VERDICT"              # dynamic page (ads/timestamps) but verdicts agree
    elif hash_ok: status = "HASH_ONLY"                  # same content, verdict split -> needs more nodes
    else: status = "NO_CONSENSUS"
    rec = {"url": url, "claim": claim_text, "quorum": quorum, "nodes": len(nodes), "status": status,
           "valid": status in ("VALID", "VALID_VERDICT"), "consensus_hash": top_hash if hash_ok else None,
           "hash_agree": hash_n, "consensus_vote": top_vote if vote_ok else None, "vote_agree": vote_n,
           "per_node": [{k: r.get(k) for k in ("node", "vote", "source_hash", "error")} for r in results]}
    if weights is not None: rec.update(weighted=True, vote_weight=vote_weight, total_weight=total_weight)
    # quorum_strength = agreeing weight / total weight over non-errored votes (unweighted: counts).
    # In [0,1]; 0.0 when there are no usable votes or total weight is 0 (never divides by zero).
    num, den = (vote_weight or 0.0, total_weight or 0.0) if weights is not None else (vote_n, sum(votes.values()))
    rec["quorum_strength"] = round(num / den, 6) if den > 0 else 0.0
    # errored: count of nodes that failed to answer (excluded from tallies; ids in per_node)
    rec["errored"] = sum(1 for r in results if r.get("error"))
    # min_strength (AEGIS_MIN_STRENGTH, 0 = off): a VALID/VALID_VERDICT round whose quorum_strength is
    # below the threshold is downgraded to NO_CONSENSUS (reason low_strength); digest reflects the downgrade.
    if min_strength and rec["valid"] and rec["quorum_strength"] < min_strength:
        rec.update(status="NO_CONSENSUS", valid=False, consensus_vote=None, consensus_hash=None,
                   reason="low_strength", downgraded_from=status, min_strength=min_strength)
    rec["receipt_digest"] = hashlib.sha256(json.dumps({k: rec[k] for k in ("url", "claim", "status", "consensus_hash", "consensus_vote")}, sort_keys=True).encode()).hexdigest()
    return rec


def canonical_json(x) -> str:
    """Sorted keys, compact separators; mirrors site/js/receipt-demo.js canonicalJson."""
    import json as _j
    return _j.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def receipt_digest(body) -> str:
    import hashlib as _h
    return "sha256:" + _h.sha256(canonical_json(body).encode()).hexdigest()


# --- peer liveness: ids peer0..N only; URLs/keys never returned ---
import time as _time
_LAST_OK = {}

def _default_get(endpoint, timeout):
    import urllib.request
    with urllib.request.urlopen(endpoint.rstrip("/") + "/v1/health", timeout=timeout) as r:
        return json.loads(r.read())

def peer_compat(h, expect):
    """Capability handshake: (ok, reason). Peer advertising a different protocol_version/claim_schema is refused;
    a peer advertising neither is treated as legacy-compatible."""
    if not expect or not isinstance(h, dict): return True, None
    pv, cs = expect
    if "protocol_version" in h and h["protocol_version"] != pv: return False, "protocol_mismatch"
    if "claim_schema" in h and h["claim_schema"] != cs: return False, "claim_schema_mismatch"
    return True, None

def ping_peers(endpoints, timeout=2.0, getter=None, now=_time.time, expect=None):
    getter = getter or _default_get
    def one(ie):
        i, e = ie; pid = f"peer{i}"; t0 = _time.monotonic()
        try:
            h = getter(e, timeout); ok = bool(h.get("ok")) if isinstance(h, dict) else False
            err = None if ok else "unhealthy"
            if ok:
                ok, err = peer_compat(h, expect)
        except Exception as ex: ok, err = False, type(ex).__name__
        if ok: _LAST_OK[e] = now()
        return {"id": pid, "ok": ok, "latency_ms": int((_time.monotonic() - t0) * 1000),
                "last_ok": _LAST_OK.get(e), **({"error": err} if err else {})}
    if not endpoints: return []
    with ThreadPoolExecutor(max_workers=len(endpoints)) as ex: return list(ex.map(one, enumerate(endpoints)))

def peer_liveness(endpoints, now=_time.time, stale_s=300):
    """Cached summary for /v1/health (no network call)."""
    t = now(); live = sum(1 for e in endpoints if e in _LAST_OK and t - _LAST_OK[e] <= stale_s)
    return {"live": live, "known": len(endpoints), "stale_after_s": stale_s}


# --- peer health hysteresis: dead after N consecutive fails, alive again after M consecutive oks ---
class PeerHealth:
    """Flap-resistant peer state. Starts 'alive'. Ids only (peer0..N); URLs never exposed."""
    def __init__(self, fail_threshold=3, recover_threshold=2, half_life=0.0, clock=None, disagree_cap=4, weight_floor=0.0,
                 agreement_window=20, agreement_threshold=0.0, agreement_min_votes=5):
        import math as _m
        if isinstance(agreement_window, bool) or not isinstance(agreement_window, int) or agreement_window < 1:
            raise ValueError("agreement_window must be an int >= 1")
        if isinstance(agreement_threshold, bool) or not isinstance(agreement_threshold, (int, float)) or not _m.isfinite(agreement_threshold) or not 0 <= agreement_threshold <= 1:
            raise ValueError("agreement_threshold must be a number in [0, 1]")
        if isinstance(agreement_min_votes, bool) or not isinstance(agreement_min_votes, int) or agreement_min_votes < 1:
            raise ValueError("agreement_min_votes must be an int >= 1")
        self.agreement_window, self.agreement_threshold = agreement_window, float(agreement_threshold)
        self.agreement_min_votes = agreement_min_votes
        if isinstance(weight_floor, bool) or not isinstance(weight_floor, (int, float)) or not _m.isfinite(weight_floor) or not 0 <= weight_floor <= 1:
            raise ValueError("weight_floor must be a number in [0, 1]")
        self.weight_floor = float(weight_floor)  # 0 = off
        if isinstance(disagree_cap, bool) or not isinstance(disagree_cap, int) or disagree_cap < 0:
            raise ValueError("disagree_cap must be an int >= 0")
        self.disagree_cap = disagree_cap  # 0 disables disagreement decay
        if fail_threshold < 1 or recover_threshold < 1: raise ValueError("thresholds must be >= 1")
        self.n, self.m = int(fail_threshold), int(recover_threshold)
        import math, time as _t
        hl = float(half_life)
        if not math.isfinite(hl) or hl < 0: raise ValueError("half_life must be finite and >= 0")
        self.half_life, self._clock = hl, (clock or _t.monotonic)
        self._s = {}  # endpoint -> {"alive", "fails", "oks"}

    def observe(self, endpoint, ok):
        s = self._s.setdefault(endpoint, {"alive": True, "fails": 0, "oks": 0})
        if ok:
            s["oks"] += 1; s["fails"] = 0; s["last_ok"] = self._clock()
            if not s["alive"] and s["oks"] >= self.m: s["alive"] = True
        else:
            s["fails"] += 1; s["oks"] = 0
            if s["alive"] and s["fails"] >= self.n: s["alive"] = False
        return s["alive"]

    # Uptime weight formula (documented contract):
    #   weight(peer) = 0                                  if peer is dead
    #   weight(peer) = 1 + min(oks, cap) / cap            if alive   -> range [1.0, 2.0]
    # where oks = consecutive successful observations (ping or vote) and cap = weight_cap (default 10).
    # A fresh/unknown peer has weight 1.0; a peer with a >= cap success streak counts double.
    # Bounded so one long-lived peer can never outvote two fresh honest peers (2.0 == 1.0 + 1.0, ties
    # break on raw count). Any failure resets oks -> weight drops back to 1.0 immediately.
    # Idle fade (optional, half_life > 0, env AEGIS_WEIGHT_HALFLIFE seconds; 0 = off):
    #   bonus = min(oks, cap)/cap * 0.5 ** (idle / half_life),  idle = now - last successful observation
    #   weight = 1 + bonus   -> stale streaks decay toward 1.0 (never below 1.0 while alive).
    weight_cap = 10

    def breakdown(self, endpoint, agreement_threshold=None):
        """{bonus, fade, dissent, weight}: weight = 0 if dead else (1 + bonus*fade) * dissent."""
        s = self._s.get(endpoint)
        if s is None: return {"bonus": 0.0, "fade": 1.0, "dissent": 1.0, "agreement": 1.0, "agreement_cut": False, "weight": 1.0, "alive": True, "floored": False}
        bonus = min(s["oks"], self.weight_cap) / self.weight_cap
        fade = 1.0
        if self.half_life > 0 and bonus > 0 and "last_ok" in s:
            fade = 0.5 ** (max(0.0, self._clock() - s["last_ok"]) / self.half_life)
        dissent = self.disagree_factor(endpoint)
        agree_f = self.agreement_factor(endpoint, agreement_threshold)
        raw = (1.0 + bonus * fade) * dissent * agree_f
        # Weight floor (AEGIS_WEIGHT_FLOOR in [0,1], 0 = off): alive peers never weigh below floor.
        # Dead peers stay 0 (liveness decides exclusion, the floor never resurrects them).
        floored = s["alive"] and raw < self.weight_floor
        w = 0.0 if not s["alive"] else max(raw, self.weight_floor)
        return {"bonus": bonus, "fade": fade, "dissent": dissent, "agreement": agree_f, "agreement_cut": agree_f < 1.0, "weight": w, "alive": s["alive"], "floored": floored}

    def weight(self, endpoint): return self.breakdown(endpoint)["weight"]

    def breakdowns(self, endpoints):
        """{peerN: breakdown} — ids only."""
        return {f"peer{i}": self.breakdown(e) for i, e in enumerate(endpoints)}

    # Disagreement decay (documented contract):
    #   factor = 0.5 ** min(d, disagree_cap),  d = consecutive votes that disagreed with a reached consensus
    #   weight = (1 + bonus) * factor  -> a chronic dissenter fades toward (1+bonus)/2**cap (cap=4 -> >= 1/16),
    #   never 0 (liveness, not disagreement, decides exclusion). One agreeing vote resets d to 0.
    #   Votes when no consensus was reached (consensus_vote None) or errored votes don't count either way.
    # disagree_cap: per-instance (ctor / env AEGIS_DISAGREE_CAP, default 4, 0 = decay off)

    def observe_vote(self, endpoint, agreed):
        s = self._s.setdefault(endpoint, {"alive": True, "fails": 0, "oks": 0})
        s["disagree"] = 0 if agreed else s.get("disagree", 0) + 1
        s["votes"] = s.get("votes", 0) + 1; s["agreed"] = s.get("agreed", 0) + (1 if agreed else 0)
        from collections import deque
        w = s.setdefault("window", deque(maxlen=self.agreement_window)); w.append(bool(agreed))
        return s["disagree"]

    # Sliding-window agreement (documented contract):
    #   window = last W counted votes (AEGIS_AGREEMENT_WINDOW, default 20, max 1000); older votes drop out.
    #   window_rate = agreed_in_window / len(window)   (None if no votes)
    # Low-agreement penalty (opt-in, AEGIS_AGREEMENT_THRESHOLD = t in [0,1], 0 = off):
    #   factor = 1                                   if t == 0, or len(window) < min_votes, or rate >= t
    #   factor = max(0.25, window_rate / t)          otherwise  -> linear, bounded >= 1/4, never 0
    #   min_votes = AEGIS_AGREEMENT_MIN_VOTES (default 5): sample-size guard so a new peer isn't
    #   punished for one unlucky vote. weight = (1 + bonus*fade) * dissent * factor (then floor).
    agreement_penalty_min = 0.25

    def window_rate(self, endpoint):
        w = self._s.get(endpoint, {}).get("window")
        return (sum(w) / len(w)) if w else None

    def agreement_factor(self, endpoint, threshold=None):
        t = self.agreement_threshold if threshold is None else threshold
        w = self._s.get(endpoint, {}).get("window")
        if t <= 0 or not w or len(w) < self.agreement_min_votes: return 1.0
        r = sum(w) / len(w)
        return 1.0 if r >= t else max(self.agreement_penalty_min, r / t)

    def agreement_rates(self, endpoints):
        """{peerN: {agreed, votes, rate}} lifetime agreement with reached consensus; rate None if no votes. Ids only."""
        out = {}
        for i, e in enumerate(endpoints):
            s = self._s.get(e, {}); v = s.get("votes", 0); a = s.get("agreed", 0)
            wr = self.window_rate(e); wn = len(s.get("window", ()))
            out[f"peer{i}"] = {"agreed": a, "votes": v, "rate": round(a / v, 6) if v else None,
                               "window_votes": wn, "window_rate": round(wr, 6) if wr is not None else None,
                               "window": self.agreement_window, "factor": self.agreement_factor(e)}
        return out

    def disagree_factor(self, endpoint):
        d = self._s.get(endpoint, {}).get("disagree", 0)
        return 0.5 ** min(d, self.disagree_cap)

    def disagreements(self, endpoints):
        """{peerN: consecutive disagreement streak} — ids only."""
        return {f"peer{i}": self._s.get(e, {}).get("disagree", 0) for i, e in enumerate(endpoints)}

    def weights(self, endpoints, agreement_threshold=None):
        """{peerN: weight} keyed by ids only (URLs never exposed)."""
        return {f"peer{i}": self.breakdown(e, agreement_threshold)["weight"] for i, e in enumerate(endpoints)}

    def agreement_cut_ids(self, endpoints, agreement_threshold=None):
        """Sorted ids (peerN) whose weight currently carries the low-agreement cut (factor < 1). Ids only."""
        return [f"peer{i}" for i, e in enumerate(endpoints) if self.is_alive(e) and self.agreement_factor(e, agreement_threshold) < 1.0]

    def is_alive(self, endpoint): return self._s.get(endpoint, {"alive": True})["alive"]

    def observe_pings(self, endpoints, results):
        for e, r in zip(endpoints, results): r["alive"] = self.observe(e, r.get("ok"))
        return results

    def summary(self, endpoints):
        alive = [e for e in endpoints if self.is_alive(e)]
        return {"alive": len(alive), "dead": len(endpoints) - len(alive), "known": len(endpoints),
                "fail_threshold": self.n, "recover_threshold": self.m,
                "weights": self.weights(endpoints), "weight_cap": self.weight_cap, "weight_half_life": self.half_life,
                "disagree_streaks": self.disagreements(endpoints), "disagree_cap": self.disagree_cap, "weight_floor": self.weight_floor,
                "agreement_window": self.agreement_window, "agreement_threshold": self.agreement_threshold,
                "agreement_min_votes": self.agreement_min_votes, "agreement_cut": self.agreement_cut_ids(endpoints)}

    def alive_endpoints(self, endpoints): return [e for e in endpoints if self.is_alive(e)]

def _env_int(name, default):
    import os
    try: return max(1, int(os.environ.get(name, default)))
    except ValueError: return default

def _env_float(name, default):
    import os, math
    try:
        v = float(os.environ.get(name, default))
        return v if math.isfinite(v) and v >= 0 else default
    except ValueError: return default

def _env_floor(name="AEGIS_WEIGHT_FLOOR", default=0.0, env=None):
    """Float in [0,1]; invalid/negative/non-finite -> default; above 1 -> 1."""
    import os, math
    env = os.environ if env is None else env
    try: v = float(str(env.get(name, default)).strip())
    except ValueError: return default
    if not math.isfinite(v) or v < 0: return default
    return min(v, 1.0)

def _env_cap(name, default, env=None, hi=16):
    """Int in [0, hi]; invalid/negative -> default; above hi -> hi (bounds the 1/2**cap floor)."""
    import os
    env = os.environ if env is None else env
    try: v = int(str(env.get(name, default)).strip())
    except ValueError: return default
    return default if v < 0 else min(v, hi)

_TRUTHY = {"1", "true", "yes", "on"}
def weighted_quorum_enabled(env=None):
    """AEGIS_WEIGHTED_QUORUM truthy (1/true/yes/on, case-insensitive) -> weighted voting."""
    import os
    env = os.environ if env is None else env
    return str(env.get("AEGIS_WEIGHTED_QUORUM", "")).strip().lower() in _TRUTHY

def resolve_weighted(body_value, env=None):
    """Per-request override: JSON bool wins; absent/None -> env flag; anything else -> ValueError."""
    if body_value is None: return weighted_quorum_enabled(env)
    if not isinstance(body_value, bool): raise ValueError("weighted must be a boolean")
    return body_value

PEER_HEALTH = PeerHealth(_env_int("AEGIS_PEER_FAILS", 3), _env_int("AEGIS_PEER_RECOVERS", 2),
                         half_life=_env_float("AEGIS_WEIGHT_HALFLIFE", 0.0),
                         disagree_cap=_env_cap("AEGIS_DISAGREE_CAP", 4),
                         weight_floor=_env_floor(),
                         agreement_window=min(_env_int("AEGIS_AGREEMENT_WINDOW", 20), 1000),
                         agreement_threshold=_env_floor("AEGIS_AGREEMENT_THRESHOLD", 0.0),
                         agreement_min_votes=_env_int("AEGIS_AGREEMENT_MIN_VOTES", 5))


# --- quorum collection skips dead peers (hysteresis) ---
def build_nodes(peer_endpoints, health=None, quorum=2, node_factory=None):
    """Returns (nodes, info). No peers configured -> local 2-fetch demo.
    Peers configured -> self + ALIVE peers only (ids keep original index; URLs never in info)."""
    health = health or PEER_HEALTH; node_factory = node_factory or http_node
    peers = [p.strip() for p in peer_endpoints if p and p.strip()]
    if not peers:
        return [local_node("self"), local_node("self-b")], {"mode": "local_demo", "known": 0, "alive": 0, "skipped": []}
    alive = set(health.alive_endpoints(peers))
    nodes = [local_node("self")] + [node_factory(f"peer{i}", e) for i, e in enumerate(peers) if e in alive]
    skipped = [f"peer{i}" for i, e in enumerate(peers) if e not in alive]
    return nodes, {"mode": "peers", "known": len(peers), "alive": len(alive), "skipped": skipped}

def consensus_alive(url, claim_text, peer_endpoints, health=None, quorum=None, node_factory=None, weighted=False,
                    min_strength=None, tracker=None, agreement_threshold=None):
    """Consensus over alive peers; too few alive -> NO_CONSENSUS with reason (no exception).
    Passive health: a peer that errors during collection counts as a failed observation.
    quorum None -> AEGIS_QUORUM (default 2); audited as quorum_applied {value, source}."""
    health = health or PEER_HEALTH
    q_applied = {"value": env_quorum() if quorum is None else quorum, "source": "env" if quorum is None else "request"}
    quorum = q_applied["value"]
    nodes, info = build_nodes(peer_endpoints, health, quorum, node_factory)
    if len(nodes) < quorum:
        return {"url": url, "claim": claim_text, "quorum": quorum, "nodes": len(nodes), "status": "NO_CONSENSUS",
                "valid": False, "reason": "insufficient_alive_peers", "consensus_hash": None, "consensus_vote": None,
                "per_node": [], "peer_selection": info, "quorum_applied": q_applied}
    _p = [p.strip() for p in peer_endpoints if p and p.strip()]
    w = None
    if weighted and _p:  # local self node = 1.0; peers by uptime streak (see PeerHealth.weight)
        w = dict(health.weights(_p, agreement_threshold)); w.setdefault("self", 1.0)
    ms = env_min_strength() if min_strength is None else min_strength
    rec = consensus(url, claim_text, nodes, quorum=quorum, weights=w, min_strength=ms)
    rec["quorum_applied"] = q_applied
    rec["min_strength_applied"] = {"value": ms, "source": "env" if min_strength is None else "request"}
    rec["agreement_threshold_applied"] = {"value": health.agreement_threshold if agreement_threshold is None else agreement_threshold,
                                          "source": "env" if agreement_threshold is None else "request"}
    cut = health.agreement_cut_ids(_p, agreement_threshold) if w is not None else []  # pre-round snapshot, like weights_used
    t = tracker or STRENGTH; t.record(rec["quorum_strength"], rec["status"])
    if rec.get("reason") == "low_strength": t.note_downgrade()
    peers = [p.strip() for p in peer_endpoints if p and p.strip()]
    for r in rec["per_node"]:
        nid = r.get("node") or ""
        if nid.startswith("peer") and nid[4:].isdigit() and int(nid[4:]) < len(peers):
            health.observe(peers[int(nid[4:])], not r.get("error"))
            if rec.get("consensus_vote") is not None and r.get("vote") and not r.get("error"):
                health.observe_vote(peers[int(nid[4:])], r["vote"] == rec["consensus_vote"])
    rec["peer_selection"] = info
    if w is not None: rec["weights_used"] = w; rec["agreement_cut"] = cut
    # audit: ids-only weights + agreement_cut snapshot taken BEFORE this round's observations
    return rec

def ping_flags(health=None, env=None):
    """Flags reported by /v1/peers/ping alongside per-peer breakdowns."""
    health = health or PEER_HEALTH
    return {"weighted_quorum": weighted_quorum_enabled(env), "disagree_cap": health.disagree_cap,
            "weight_floor": health.weight_floor}

def attach_breakdowns(health, endpoints, results):
    """Add ids-only weight breakdown to ping results (no URLs; keyed by position)."""
    for e, r in zip(endpoints, results): r["weight"] = health.breakdown(e)
    return results


def resolve_agreement_threshold(body_value):
    """Per-request agreement_threshold: None -> env/instance default (returns None); else finite number in [0,1] (not bool)."""
    import math
    if body_value is None: return None
    if isinstance(body_value, bool) or not isinstance(body_value, (int, float)) or not math.isfinite(body_value) \
            or not 0.0 <= body_value <= 1.0:
        raise ValueError("agreement_threshold must be a number in [0,1]")
    return float(body_value)

QUORUM_MIN, QUORUM_MAX = 2, 16

def env_quorum(env=None):
    """AEGIS_QUORUM int in [2,16]; unset/invalid/<2 -> 2; >16 -> 16."""
    import os
    env = os.environ if env is None else env
    try: v = int(str(env.get("AEGIS_QUORUM", QUORUM_MIN)).strip())
    except ValueError: return QUORUM_MIN
    return QUORUM_MIN if v < QUORUM_MIN else min(v, QUORUM_MAX)

def resolve_quorum(body_value, env=None):
    """Per-request quorum: None -> env default (returns None); else JSON int (not bool/float) in [2,16]
    and >= env quorum (a request may only TIGHTEN the operator floor, never weaken it)."""
    if body_value is None: return None
    if isinstance(body_value, bool) or not isinstance(body_value, int) or not QUORUM_MIN <= body_value <= QUORUM_MAX:
        raise ValueError(f"quorum must be an integer in [{QUORUM_MIN},{QUORUM_MAX}]")
    floor = env_quorum(env)
    if body_value < floor: raise ValueError(f"quorum {body_value} below operator floor AEGIS_QUORUM={floor}")
    return body_value

def resolve_min_strength(body_value):
    """Per-request min_strength: None -> env default (returns None); else finite number in [0,1] (not bool)."""
    import math
    if body_value is None: return None
    if isinstance(body_value, bool) or not isinstance(body_value, (int, float)) or not math.isfinite(body_value) \
            or not 0.0 <= body_value <= 1.0:
        raise ValueError("min_strength must be a number in [0,1]")
    return float(body_value)

# --- quorum strength rolling stats + AEGIS_MIN_STRENGTH ---
def env_min_strength(env=None):
    """AEGIS_MIN_STRENGTH float in [0,1]; invalid/negative/non-finite -> 0 (off); >1 -> 1."""
    return _env_floor("AEGIS_MIN_STRENGTH", 0.0, env)

class StrengthTracker:
    """Rolling window of recent consensus rounds (strength only; no URLs/claims stored)."""
    def __init__(self, window=20):
        if isinstance(window, bool) or not isinstance(window, int) or window < 1: raise ValueError("window must be int >= 1")
        from collections import deque
        self._d = deque(maxlen=window); self.window = window; self.downgraded = 0; self.rounds = 0
    def record(self, strength, status=None):
        self._d.append(float(strength)); self.rounds += 1
        return strength
    def note_downgrade(self): self.downgraded += 1
    def summary(self):
        d = list(self._d)
        return {"latest": d[-1] if d else None, "avg": round(sum(d) / len(d), 6) if d else None,
                "min": min(d) if d else None, "samples": len(d), "window": self.window, "rounds": self.rounds,
                "downgraded": self.downgraded}

def _env_window(env=None):
    """AEGIS_STRENGTH_WINDOW int in [1,1000]; invalid/<1 -> 20; >1000 -> 1000."""
    import os
    env = os.environ if env is None else env
    try: v = int(str(env.get("AEGIS_STRENGTH_WINDOW", 20)).strip())
    except ValueError: return 20
    return 20 if v < 1 else min(v, 1000)

STRENGTH = StrengthTracker(_env_window())
