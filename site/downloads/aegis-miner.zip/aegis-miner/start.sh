#!/bin/sh
# AegisAI desktop miner
# Simulation:  ./start.sh
# PoV-R live:  python3 -m aegis_miner --pov-wallet <pubkey>
#   fetch→solve→unsigned claim msg (no keys). Sign in Phantom, then claim.
# Offline demo: python3 -m aegis_miner --pov-local --pov-n 8
cd "$(dirname "$0")"
exec python3 main.py "$@"
